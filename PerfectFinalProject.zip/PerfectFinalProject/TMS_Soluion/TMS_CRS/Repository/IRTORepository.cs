﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using TMS_CRS.Models;

//namespace TMS_CRS.Repository
//{
//    public interface IRTORepository
//    {
//        Task<TmOwnerdetail>AddOwner(TmOwnerdetail ownerdetail);
//        bool Transferdetails(TmRegdetail regdetail, string appno);
//        Task<TmVehicleDetail> AddVechile(TmVehicleDetail vehicleDetail);
//        Task<TmRegdetail> Registration(TmRegdetail regdetail);
//        Task<IEnumerable<TmRegdetail>> GetAll();
//        List<TmRegdetail> GenerateReport(int id);
//        Task<TmRegdetail> GetById(string appno);
        
       



//    }
//}
////Addowner
////Add vechiled etails
////transefer details
////regstaration
////generate report