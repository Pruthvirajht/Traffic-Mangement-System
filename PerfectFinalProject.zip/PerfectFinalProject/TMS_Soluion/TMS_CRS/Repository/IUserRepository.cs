﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using TMS_CRS.Models;
//using TMS_CRS.Repository;

//namespace TMS_CRS.Repository
//{
//    public interface IUserRepository
//    {
//        bool AddUser(TmUserMaster user);
//    }
//}
